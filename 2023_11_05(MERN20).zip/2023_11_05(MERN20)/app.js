const { Console, error } = require("console");
const os = require("os");
const prompt = require("prompt");


//prompt.start();

//const schema = ["id", "name"];

//Calling async method using callbacks
// prompt.get(schema, (error, result) => {
//     if (result) {
//         console.log(`Id: ${result.id}`);
//         console.log(`Name: ${result.name}`);        
//     }
//     else {
//         console.log(error);
//     }
//     console.log("done");    
// });

//Calling async method using promise - simple
//const promise = prompt.get(schema);
// promise.then((result)=>{
//     console.log(`Id: ${result.id}`);
//     console.log(`Name: ${result.name}`);        
// });
// promise.catch((error)=>{
//     console.log(error);
// });
// promise.finally(()=>{
//     console.log("done");
// });

//Calling async method using promise - chaining
// prompt.get(schema)
//     .then((result) => {
//         console.log(`Id: ${result.id}`);
//         console.log(`Name: ${result.name}`);
//     })
//     .catch((error) => {
//         console.log("error");
//     })
//     .finally(() => {
//         console.log("done");
//     });

//Calling async method using await 
// async function Run() {
//     try {
//         const result = await prompt.get(schema);
//         console.log(`Id: ${result.id}`);
//         console.log(`Name: ${result.name}`);
//     }
//     catch (error) {
//         console.log(error);
//     }
//     finally{
//         console.log("done");
//     }
// }


Run();


async function Run() {
    prompt.start();
    const schema = {
        "properties" : {
            "loginid" : {
                "description" : "Enter login id",
                "type" : "string",
                
            },
            "password" : {
                "description" : "Enter password",
                "type" : "string",
                "hidden" : true,
                "replace":"x",
            },
        }       
    };
    try {
        const result = await prompt.get(schema);
        console.log(`Login Id: ${result.loginid}`);
        console.log(`Password: ${result.password}`);
    }
    catch (error) {
        console.log(error);
    }
    finally {
        console.log("done");
    }
}










