const os=require("os");
const prompt=require("prompt");

//prompt.start();
//const schema=
//prompt.get();



console.log(`Currently login user: ${os.userInfo().username}`);
console.log(`Total Memory in GHz: ${os.totalmem/1024/1024/1024}`);
console.log(`Free Memory in GHz: ${os.freemem/1024/1024/1024}`);
