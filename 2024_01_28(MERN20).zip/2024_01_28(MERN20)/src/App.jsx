import logo from './logo.svg';
import './App.css';
import UserStatus from './components/demos/userstatus';
import { Container } from 'react-bootstrap';

function App() {
  return (
    <Container fluid >
      <UserStatus userName="alimalik" role="admin" />
    </Container>

  );
}

export default App;
