use("pakclassified20")

db.statuses.insertMany(
    {
        "name" : "Pending",
    },
    {
        "name" : "Approved",
    },
    {
        "name" : "Rejected",
    }
)



db.advertisements.insertOne(
    {
        "title" : "iPhone XII at lowest price",
        "price" : 110000,
        "postedon": new Date(),
        "startdate": new Date(2024,1,1),
        "enddate": new Date(2024,1,31),
        "description" : "iPhone XII in outstanding condition for sale in gulberg 3 Lahore at lowest price"
    }
)


db.categories.find(
    { "name" : "Laptops" }
)