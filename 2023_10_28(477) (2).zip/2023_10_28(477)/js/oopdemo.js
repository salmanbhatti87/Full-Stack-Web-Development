class Product{
    constructor(id,name,price,gstRate){
        this._Id=id;
        this._Name=name;
        this._Price=price;
        this._GstRate=gstRate;
    }

    //setter
    set Id(value){
        if(value>0){
            this._Id=id;
        }
        else{
            console.log("id must be a +ve number");
        }
    }

    get Id(){
        return this._Id;
    }

    set Name(value){
        this._Name=value;
    }

    get Name(){
        return this._Name;
    }

    set Price(value){
        this._Price=value;
    }

    get Price(){
        return this._Price;
    }

    // setId(value){
    //     if(value>0){
    //         this._Id=id;
    //     }
    //     else{
    //         console.log("id must be a +ve number");
    //     }
    // }

    // getId(){
    //     return this._Id;
    // }




    get GstAmount(){
        return Math.round(this.Price * this._GstRate / 100);
    }

    get RetailPrice(){
        return this.Price + this.GstAmount;
    }
}
