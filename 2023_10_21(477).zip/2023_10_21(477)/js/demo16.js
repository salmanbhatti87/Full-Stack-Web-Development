const categories = ["Laptops", "Mobiles", "Accessories"];

const productNames = ["Aaaa", "Bbbb", "Cccc", "Dddd"];
const productPrices = [1000, 700, 1200, 1900];
const productCategories = [categories[1], categories[2], categories[1], categories[2]];


addEventListener("load", function () {
    loadCategories();
    loadProducts();
})

document.getElementById("btnAdd").addEventListener("click",function(){
    let eltName = document.getElementById("txtName");
    let eltPrice = document.getElementById("txtPrice");
    let eltCategory = document.getElementById("ddlCategory");

    productNames.push(eltName.value);
    productPrices.push(Number(eltPrice.value));
    productCategories.push(categories[eltCategory.value]);

    loadProducts();
})


function loadCategories(){
    let temp = `<option value="-1">Select Category</option>`;
    for (let i = 0; i < categories.length; i++) {
        temp += `<option value="${i}">${categories[i]}</option>`;
    }
    this.document.getElementById("ddlCategory").innerHTML = temp;
}

function loadProducts(){
    let eltBody = document.getElementById("tblBody");
    eltBody.innerHTML="";
    for (let i = 0; i < productNames.length; i++) {
        const gstAmount=Math.floor(productPrices[i]*18/100);
        const retailPrice=productPrices[i]+gstAmount;

        let row = `<tr class="row" >
            <td class="col-3">${productNames[i]}</td>
            <td class="col-3">${productCategories[i]}</td>
            <td class="col-2">${productPrices[i]}</td>
            <td class="col-2">${ gstAmount }</td>
            <td class="col-2">${ retailPrice }</td>
        </tr>`;
        eltBody.innerHTML+=row;
    }
}