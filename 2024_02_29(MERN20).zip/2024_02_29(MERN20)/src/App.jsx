import './App.css';
import UserStatus from './components/demos/userstatus';
import { Col, Container, Form, ListGroup, Row } from 'react-bootstrap';
import ImageWithPreview from './components/demo02/ImageWithPreview';
import ChildrenDemo from './components/demo03/ChildrenDemo';
import StateDemo from './components/demo04/StateDemo';
import { SearchTask, TaskItemList } from './components/taskmgt/taskitemcomponents';
import Header from './components/shared/Header';
import { Link, Route, Routes } from 'react-router-dom';
import { Home, Tasks, About, NotFound, Dashboard, ManageTeam, ManageTask, AdminLayout, MainLayout } from './components/routingdemo/Pages';

function App() {
  const images = ["images/garments/p1.jpg", "images/garments/p2.jpg", "images/garments/p3.jpg"];
  const categories = [
    { id: 1, name: "personal" },
    { id: 2, name: "work" },
    { id: 3, name: "learning" },
  ];

  const priorities = [
    { id: 1, name: "urgent", color: "bg-danger" },
    { id: 2, name: "high", color: "bg-danger" },
    { id: 3, name: "normal", color: "bg-warning" },
    { id: 4, name: "low", color: "bg-success" },
    { id: 5, name: "very low", color: "bg-success" }
  ];

  const taskItems = [
    {
      id: 1,
      title: "Create UI for TaskMgt System",
      details: "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Hic numquam magni repellendus pariatur facilis cum praesentium repellat labore voluptate provident atque, asperiores aliquam maxime ex quaerat aperiam. Culpa, quam dolore!",
      duedate: new Date("2024-2-20"),
      progress: 60,
      priority: priorities[1],
      category: categories[0]
    },
    {
      id: 2,
      title: "aaaaaaaa aaaaaaaaaa aaaaa",
      details: "aaaaaaaaa aaaaaaaaaaaaa aaaaaaaaa aaaaaaaaaaa aaaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaaaa aaaaaaaaaaa aaaaaaaaaaa aaaaaaaaaa",
      duedate: new Date("2024-2-5"),
      progress: 75,
      priority: priorities[1],
      category: categories[0]
    },
  ]


  return (
    <>
      <Container fluid>
        <Row>
          <Col className='col-3'>
            <ListGroup>
              <ListGroup.Item><Link to='/home'>Home</Link> </ListGroup.Item>
              <ListGroup.Item><Link to='/tasks/1/Personal' >Personal Tasks</Link> </ListGroup.Item>
              <ListGroup.Item><Link to='/tasks/2/Office' >Office Tasks</Link> </ListGroup.Item>
              <ListGroup.Item><Link to='/tasks/3/Learning' >Learning Tasks</Link> </ListGroup.Item>
              <ListGroup.Item><Link to='/about' >About</Link> </ListGroup.Item>
            </ListGroup>
          </Col>
          <Col>
            <Routes>
              <Route path='/' element={<MainLayout />}  >
                <Route index element={<Home />} />
                <Route path='/home' element={<Home />} />
                <Route path='/tasks/:cid/:name' element={<Tasks />} />
                <Route path='/about' element={<About />} />
              </Route>
              <Route path="/admin/" element={<AdminLayout />}  >
                <Route index element={<Dashboard />} />
                <Route path='home' element={<Dashboard />} />
                <Route path='teams' element={<ManageTeam />} />
                <Route path='tasks' element={<ManageTask />} />
              </Route>
              <Route path='*' element={<NotFound />} />
            </Routes>

          </Col>
        </Row>
      </Container>
    </>
  );
}

export default App;
