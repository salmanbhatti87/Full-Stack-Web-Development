import { Outlet, useParams } from "react-router-dom";

export function Home() {
    return (
        <>
            <h1>Home</h1>
            <hr />
            <p>Contents of home page here</p>
        </>
    )
}

export function Tasks(props) {
    const {cid,name}=useParams();
    return (
        <>
            <h1>{name} Tasks</h1>
            <hr />
            <p>Contents of {name} tasks</p>
            <p>Category Id is {cid}</p>
        </>
    );
}


export function About() {
    return (
        <>
            <h1>About</h1>
            <hr />
            <p>Contents of about page</p>
        </>
    )
}


export function Dashboard() {
    return (
        <>
            <h1>Admin Dashboard</h1>
            <hr />
            <p>Admin dashboard here</p>
        </>
    )
}

export function ManageTeam() {
    return (
        <>
            <h1>Manage Team</h1>
            <hr />
            <p>Manage Team Page</p>
        </>
    )
}


export function ManageTask() {
    return (
        <>
            <h1>Manage Tasks</h1>
            <hr />
            <p>Manage Tasks Page</p>
        </>
    )
}


export function NotFound() {
    return (
        <>
            <h1>Error</h1>
            <hr />
            <p>Invalid path, no such page exists</p>
        </>
    )
}


export function MainLayout(){
    return (
        <>
            <header>
               <h1>MERN20 at EVS Lahore</h1> 
            </header>
            <main>
                <Outlet />
            </main>
            <footer>
                <p>Footer here</p>
            </footer>            
        </>
    )
}


export function AdminLayout(){
    return (
        <>
            <header>
               <h1>MERN20 - Admin</h1> 
            </header>
            <main>
                <Outlet />
            </main>
            <footer>
                <p>EVS Institute Lahore</p>
            </footer>            
        </>
    )
}