import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import './taskitemcomponents.css';
import { Row, Col, Badge, Button, Card, CardBody, Container, Form, InputGroup, FormControl } from 'react-bootstrap';

export function TaskItemList(props) {
    const tasksArray = props.tasks;
    return (
        <>
            <Card>
                <Card.Header className='bg-primary text-white'>
                    <Card.Title><FontAwesomeIcon icon={props.icon} /> {props.heading}</Card.Title>
                </Card.Header>
                <Card.Body>
                    <Row>
                        {
                            tasksArray.map(t => (
                                <Col key={t.id} className='col-4'>
                                    <TaskItem task={t} />
                                </Col>
                            ))
                        }
                    </Row>
                </Card.Body>
            </Card>

        </>
    )
}


export function TaskItem(props) {
    const item = props.task;
    return (
        <>
            <div className='card-task' >
                <div className='card-task-header' >
                    <h2>{item.title}</h2>
                </div>
                <div className="card-task-details">
                    <Row className="mb-3" >
                        <Col className='card-task-description' >
                            {item.details}
                        </Col>
                    </Row>
                    <Row>
                        <Col className="col-9 card-task-duedate"> {item.duedate.toDateString()}  </Col>
                        <Col className="card-task-progress">{item.progress}%</Col>
                    </Row>
                </div>
                <div className="card-task-footer">
                    <Row>
                        <Col>
                            <Badge className='bg-primary'>{item.category.name}</Badge>&nbsp;
                            <Badge className={item.priority.color}>{item.priority.name}</Badge>
                        </Col>
                        <Col className='text-end' >
                            <Button variant='outline-light' className="text-warning"><FontAwesomeIcon icon="fas fa-edit" /></Button>
                            <Button variant='outline-light' className="text-danger"><FontAwesomeIcon icon="fas fa-trash" /></Button>
                        </Col>
                    </Row>
                </div>

            </div>
        </>
    )
}


export function SearchTask(props) {
    return (
        <>
            <Container fluid className='my-4' >
                <Row className='search-section justify-content-center align-items-center'>
                    <Col className='col-10' >
                        <Form>
                            <Form.Group className="mb-3">
                                <InputGroup >
                                    <InputGroup.Text> Search </InputGroup.Text>
                                    <FormControl placeholder="Keyword" />
                                    <Button variant='light' ><FontAwesomeIcon icon="fas fa-magnifying-glass"/> </Button>
                                </InputGroup>                                
                            </Form.Group>
                        </Form>
                    </Col>
                </Row>
            </Container>
        </>
    );
}