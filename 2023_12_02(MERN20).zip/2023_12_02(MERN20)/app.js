const path=require("path");
const dotenv=require("dotenv");
dotenv.config();

const express=require("express");
const { stringify } = require("querystring");
const app=express();
const port=Number(process.env.PORT_NUMBER);
const host=process.env.HOST_NAME;
const publicFolderPath=process.env.PUBLIC_FOLDER_PATH;
const publicFolder=path.resolve(__dirname,publicFolderPath);

const demoRouter=require("./routes/demo.routes");

app.use("/demo",demoRouter);



// app.get("/",(req,res)=>{
//    //let filePath =`${__dirname}\\public\\test.html`;
//    let filePath =path.resolve(__dirname,"public","test.html"); 
//    console.log(filePath);
//    res.status(200).sendFile(filePath);
//   // return res.status(200).send("done");   
// });

app.all("*",(req,res)=>{
   return res.status(400).send("bad request");   
});

app.listen(port,host,()=>{
   console.log(`The server is listening on port#${port}`);
});


