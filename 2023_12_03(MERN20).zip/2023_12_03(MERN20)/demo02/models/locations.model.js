class Country {
    constructor(name, code) {
        this.Name = name;
        this.Code = code;
    }

    get Summary() {
        return `${this.Code},${this.Name}`;
    }
}

class City {
    constructor(name, country) {
        this.Name = name;
        this.Country = country;
    }

    get Summary() {
        return `${this.Name},${this.Country.Name}`;
    }
}

module.exports={Country, City};

