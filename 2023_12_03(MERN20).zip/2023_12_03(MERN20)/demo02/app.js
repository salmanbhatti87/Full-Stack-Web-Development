const path=require("path");
const  dotenv=require("dotenv");
const express=require("express");
dotenv.config();
const port = process.env.PORT_NUMBER;
const host=process.env.HOST_NAME;
const publicFolder=process.env.PUBLIC_FOLDER_PATH;

const countryRouter=require("./routes/countries.routes");
const app=express();

app.use("/api/countries",countryRouter);


app.listen(port,host,(req,res)=>{
    console.log(`server is listening on ${port}`);
})



