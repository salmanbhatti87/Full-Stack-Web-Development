

let Message=`Welcome guest`;

const GetMessage=function(){
    return Message;
}

const SetMessage=function(value){
    Message=value;
}

// class Country{
//     constructor(id,name,code){
//         this.id=id;
//         this.name=name;
//         this.code=code;
//     }
// }

module.exports= { GetMessage, SetMessage };
