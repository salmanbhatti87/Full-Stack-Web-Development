
const getHost=function(req,res,next){
    console.log(`${req.hostname}`);
    //return res.status(404).send("error");
    next();
 }

 module.exports=getHost;