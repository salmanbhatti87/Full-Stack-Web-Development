const express=require("express");
const demoRouter=express.Router();

demoRouter.get("/",(req,res)=>{
    return res.status(200).send("default from demo router");
})

demoRouter.get("/all",(req,res)=>{
    return res.status(200).send("all from demo router");
})



module.exports=demoRouter;