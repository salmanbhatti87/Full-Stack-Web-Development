const path=require("path");
const dotenv=require("dotenv");
dotenv.config();




const express=require("express");
const app=express();
const port=Number(process.env.PORT_NUMBER);
const host=process.env.HOST_NAME;
const publicFolderPath=process.env.PUBLIC_FOLDER_PATH;

const publicFolder=path.resolve(__dirname,publicFolderPath);
app.use(express.static(publicFolder));
const getHost=require("./middleware/simple.middleware");
app.use(getHost);

const demoRouter=require("./routes/demo.routes");
app.use("/demo",demoRouter);


app.get("/",(req,res)=>{
   return res.status(200).send("test");
});






app.all("*",(req,res)=>{
   return res.status(400).send("bad request");   
});

app.listen(port,host,()=>{
   console.log(`The server is listening on port#${port}`);
});


