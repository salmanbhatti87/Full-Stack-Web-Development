import "./userstatus.css"

export default function UserStatus(props) {
    const temp=props.userName;
    return(
        <>
            <div className="userstatus-sec">
                Welcome <strong>{ (temp!=null) ? `${props.userName}, ${props.role}` : "guest" }</strong>
            </div>
        </>
    )
    // return (
    //     //<React.Fragment>
    //     <>
    //         <h1></h1>
    //         <div>aaa</div>
    //     </>

    //     //</React.Fragment>        
    // );
}