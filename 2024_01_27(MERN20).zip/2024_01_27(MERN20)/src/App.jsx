import logo from './logo.svg';
import './App.css';
import UserStatus from './components/demos/userstatus';

function App() {
  return (
    <div style={{ padding:"15px" }} >
      <UserStatus userName="alimalik" role="admin"  />
    </div>
  );
}

export default App;
