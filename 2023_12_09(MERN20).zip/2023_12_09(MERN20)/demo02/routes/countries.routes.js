const express = require("express");
const LocationsDAL = require("../dal/locations.dal");

const countryRouter = express.Router();
const locationsDal = new LocationsDAL();

countryRouter.get("/:id", async (req, res) => {
    try {
        throw console.error();
        const id =Number(req.params.id);
        if(id<1) return res.status(400).send("id can't zero or negative number");
        const country = await locationsDal.GetCountry(id);
        if(country){
            return res.status(200).json(country);        
        }
        return res.status(404).send(`country against given id:${id} is not found`);
    }
    catch(ex) {
        res.status(500).send(ex);
    }
});


countryRouter.get("/", async (req, res) => {
    try {
        const countriesArray = await locationsDal.GetCountries();
        return res.status(200).json(countriesArray);
    }
    catch(ex) {
        res.status(500).send(ex);
    }
});

module.exports=countryRouter;