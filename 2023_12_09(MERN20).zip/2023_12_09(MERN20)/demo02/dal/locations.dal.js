const { Country, City } =require("../models/locations.model");


class LocationsDAL {
    constructor() {
        this.counteries = [
            new Country("Pakistan", 92),
            new Country("Afghanistan", 93)
        ];

        this.cities = [
            new City("Lahore", this.counteries[0]),
            new City("Islamabad", this.counteries[0]),
            new City("Karachi", this.counteries[0]),
            new City("Kabul", this.counteries[1])
        ];
    }


    //CRUD



    async GetCountry(code) {
        return this.counteries.find(c => c.Code == code);
    }

    async GetCountries() {
        return [...this.counteries];
    }


    GetCity(name) {
        return this.cities.find(c => c.Name == name);
    }

    GetCities() {
        // let newArray=[...this.cities];
        // return newArray;
        return [...this.cities];
    }

    AddCity(name, countryCode) {
        try {
            const country = this.GetCountry(countryCode);
            const city = new City(name, country);
            this.cities.push(city);
            return city;
        }
        catch(error){
            console.log(error);
            return null;
        }
    }

    DeleteCity(name) {
        try {
            const index=this.cities.findIndex(c=>c.Name==name);
            if(index>=0){
                const toDelete = this.cities[index];
                this.cities.splice(index,1);
                return toDelete;
            }
            return null;
        }
        catch(error){
            console.log(error);
            return null;
        }
    }

    UpdateCity(name,newName,newCountryCode) {
        try {
            const found=this.cities.find(c=>c.Name==name);
            if(found){
                found.Name=newName;
                found.Country=this.GetCountry(newCountryCode);
                return found;
            }
            return null;
        }
        catch(error){
            console.log(error);
            return null;
        }
    }

}


module.exports=LocationsDAL;