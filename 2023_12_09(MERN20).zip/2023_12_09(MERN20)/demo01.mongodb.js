use("pakclassified20")

// db.categories.insertMany(
//     [
//         {
//             "name" : "Bikes",
//             "image" : "bikes.png"            
//         },
//         {
//             "name" : "Books",
//             "image" : "books.png"            
//         }
//     ]
// )

// db.categories.find(
//     { "name" : "Laptops" }
// )