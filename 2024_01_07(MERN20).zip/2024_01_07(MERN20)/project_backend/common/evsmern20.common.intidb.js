const { mongoose } = require("mongoose");
const { Country, Province, City, CityArea } = require("../models/evsmern20.models.locations");
const dotenv = require("dotenv");
dotenv.config();


const initDB = async function () {
    mongoose.connect(process.env.CON_STR);




    // const countries = [
    //     { "name": "Pakistan", "code": 92 },
    //     { "name": "India", "code": 91 },
    // ];

    // countries.forEach(async country => {
    //     try {
    //         const insertedCountry = await Country.create(country);
    //         console.log(insertedCountry);
    //     }
    //     catch (error) {
    //         console.log(error);
    //     }
    // });

    // try {
    //     const pkProvinces=[ "Islamabad Capital Territory", "Punjab", "Sindh", "Khyber Pakhtoon Khwa", "Baluchistan", "Gilgit Baltistan", "Azad Jammu Kashmir" ];
    //     const pk = await Country.findOne({ "code": 92 })
    //     pkProvinces.forEach(async province=>{
    //         const p = await Province.create({ "name" :  province, "country": pk._id });
    //         console.log(p);
    //     });        
    // }
    // catch (error) {
    //     console.log(error);
    // }

    try {
        const pkProvinces=[ "Islamabad Capital Territory", "Punjab", "Sindh", "Khyber Pakhtoon Khwa", "Baluchistan", "Gilgit Baltistan", "Azad Jammu Kashmir" ];
        const c1 = await City.create( { name : "Islamabad", province : await Province.findOne("Islamabad Capital Territory") });
        const puCities=["Lahore", "Faisalabad", "Multan" ];
        const pu=Province.findOne("Punjab");
        const pk = await Country.findOne({ "code": 92 })
        pkProvinces.forEach(async province=>{
            const p = await Province.create({ "name" :  province, "country": pk._id });
            console.log(p);
        });        
    }
    catch (error) {
        console.log(error);
    }




}

module.exports = initDB;