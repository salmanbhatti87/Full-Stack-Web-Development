use("pakclassified20")

// db.categories.findOne(
//     {
//        "_id" :  ObjectId("6574795bec6a6a586ba92782")    
//     }
// )

// db.categories.update(
//     {
//         "_id" :  ObjectId("6574795bec6a6a586ba92782")
//     },
//     {
//         $set : { "name" : "aaa", "image" : "aaa.png"  }
//     }    
// )

// db.categories.findOne(
//     {
//         "_id" :  ObjectId('id')

//     }
// )


// db.categories.deleteOne(
//     {
//         "_id": ObjectId("6574795bec6a6a586ba92782")
//     }        
// )

// db.countries.insertMany(
//     [
//         { "code" : 92, "name" : "Pakistan" },
//         { "code" : 91, "name" : "India" }
//     ]
// )

//  db.countries.find();

// db.cities.insertMany(
//     [
//         { "name" : "Lahore",  "countryid" :  ObjectId('657db68364249e82b6b8895e')   },
//         { "name" : "Islamabad",  "countryid" :  ObjectId('657db68364249e82b6b8895e')   },
//         { "name" : "Karachi",  "countryid" :  ObjectId('657db68364249e82b6b8895e')   },
//         { "name" : "Faisalabad",  "countryid" :  ObjectId('657db68364249e82b6b8895e')   },
//         { "name" : "Dehli",  "countryid" :  ObjectId('657db68364249e82b6b8895f')   },
//         { "name" : "Ahmedabad",  "countryid" :  ObjectId('657db68364249e82b6b8895f')   }        
//     ]
// )

//db.cities.find();

// db.users.insertOne(
//         {
//             "fullname" : "muhammad amir",
//             "loginid" : "amir",
//             "password": "12345678",
//             "birthdate": "2005-12-20",
//             "address" : {
//                 "streetaddress" : "349 Ferozepur Road",
//                 "city" : ObjectId("657db748e49e5821ae43a37d"),
//             },
//             "contactnumbers" : ["0300-1111111", "0333-1111111", "0311-1111111" ]
//         }    
// )

// db.users.find()

db.cities.find(
    {
        "countryid" :  ObjectId('657db68364249e82b6b8895e')
    },
    {
        "_id" : 0, "countryid" : 0
    }
).sort(
    {
        "name" : 1
    }
).limit(3).skip(2)








// db.categories.find()

