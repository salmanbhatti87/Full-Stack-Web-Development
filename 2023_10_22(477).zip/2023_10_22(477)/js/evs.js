
document.querySelectorAll(".img-thumbnail").forEach(img => img.addEventListener("mouseenter", function (e) {
    const temp = this.getAttribute("src"); //e.target.getAttribute("src");
    const targetId=this.getAttribute("data-evs-target");
    document.querySelector(targetId).setAttribute("src", temp)
}));

document.querySelector(".evs-imgwithalt").addEventListener("mouseenter",function(){
    const src = this.getAttribute("src");
    const alt=this.getAttribute("data-evs-altsrc");
    this.setAttribute("src",alt);
    this.setAttribute("data-evs-altsrc",src);
})

document.querySelector(".evs-imgwithalt").addEventListener("mouseleave",function(){
    const src = this.getAttribute("src");
    const alt=this.getAttribute("data-evs-altsrc");
    this.setAttribute("src",alt);
    this.setAttribute("data-evs-altsrc",src);
})