const initDB=require("./common/evsmern20.common.intidb");

initDB().then(r=>{
    console.log("done");
});



