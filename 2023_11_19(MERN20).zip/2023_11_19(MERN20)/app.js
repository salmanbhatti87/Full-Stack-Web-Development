const { City, Country, LocationsHandler } = require("./mymodules/locations");
const prompt = require("prompt");

const handler = new LocationsHandler();


//handler.GetCities().forEach(c=>console.log(c));
//handler.AddCity("Queta",92);
//handler.UpdateCity("Lahore","Qandhar",93);
//handler.DeleteCity("Lahore");
//handler.GetCities().forEach(c=>console.log(c));
prompt.start();
Run();

async function Run() {
    let isContinue=true;
    while (isContinue) {
        console.log("Main Menu");
        console.log("1. Add City");
        console.log("2. Find City");
        console.log("3. Update City");
        console.log("4. Delete City");
        console.log("5. List All Citis");
        console.log("6. Exit");

        const result = await prompt.get("choice");
        switch (Number(result.choice)) {
            case 1:
                await Add();
                break;
            case 2:
                console.log("find");
                break;
            case 3:
                console.log("update");
                break;
            case 4:
                console.log("delete");
                break;
            case 5:
                ListCities();
                break;
            case 6:
                isContinue=false;
                break;
            default:
                console.log("invalid choice");
                break;

        }
    }
}


async function Add(){
    console.log("Add City");
    console.log("--------");
    const schema={
        "properties" : {
            "Name" : {
                "description" : "Enter city name: ",
                "type" : "string"
            },
            "CountryCode" : {
                "description" : "Enter country code: ",
                "type" : "number"
            }
        }
    }
    const result =await prompt.get(schema);

    const newCity = handler.AddCity(result.Name,result.CountryCode);
    if(newCity){
        console.log(`${newCity.Name} added successfully`);
    }
    else {
        console.log(`failed to add ${newCity.Name}`);
    }

}

function ListCities(){
    const cities = handler.GetCities();
    cities.forEach(c=>{
        console.log(`${c.Name}\t${c.Country.Name}`);
    })
}









