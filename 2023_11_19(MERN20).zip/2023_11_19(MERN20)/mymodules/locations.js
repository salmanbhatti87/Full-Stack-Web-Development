class Country {
    constructor(name, code) {
        this.Name = name;
        this.Code = code;
    }

    get Summary() {
        return `${this.Code},${this.Name}`;
    }
}

class City {
    constructor(name, country) {
        this.Name = name;
        this.Country = country;
    }

    get Summary() {
        return `${this.Name},${this.Country.Name}`;
    }
}

class LocationsHandler {
    constructor() {
        this.counteries = [
            new Country("Pakistan", 92),
            new Country("Afghanistan", 93)
        ];

        this.cities = [
            new City("Lahore", this.counteries[0]),
            new City("Islamabad", this.counteries[0]),
            new City("Karachi", this.counteries[0]),
            new City("Kabul", this.counteries[1])
        ];
    }


    //CRUD



    GetCountry(code) {
        return this.counteries.find(c => c.Code == code);
    }


    GetCity(name) {
        return this.cities.find(c => c.Name == name);
    }

    GetCities() {
        // let newArray=[...this.cities];
        // return newArray;
        return [...this.cities];
    }

    AddCity(name, countryCode) {
        try {
            const country = this.GetCountry(countryCode);
            const city = new City(name, country);
            this.cities.push(city);
            return city;
        }
        catch(error){
            console.log(error);
            return null;
        }
    }

    DeleteCity(name) {
        try {
            const index=this.cities.findIndex(c=>c.Name==name);
            if(index>=0){
                const toDelete = this.cities[index];
                this.cities.splice(index,1);
                return toDelete;
            }
            return null;
        }
        catch(error){
            console.log(error);
            return null;
        }
    }

    UpdateCity(name,newName,newCountryCode) {
        try {
            const found=this.cities.find(c=>c.Name==name);
            if(found){
                found.Name=newName;
                found.Country=this.GetCountry(newCountryCode);
                return found;
            }
            return null;
        }
        catch(error){
            console.log(error);
            return null;
        }
    }




}




module.exports = { Country, City, LocationsHandler };