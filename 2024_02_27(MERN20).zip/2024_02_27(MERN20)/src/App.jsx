import './App.css';
import UserStatus from './components/demos/userstatus';
import { Col, Container, Form, Row } from 'react-bootstrap';
import ImageWithPreview from './components/demo02/ImageWithPreview';
import ChildrenDemo from './components/demo03/ChildrenDemo';
import StateDemo from './components/demo04/StateDemo';
import { SearchTask, TaskItemList } from './components/taskmgt/taskitemcomponents';
import Header from './components/shared/Header';

function App() {
  const images = ["images/garments/p1.jpg", "images/garments/p2.jpg", "images/garments/p3.jpg"];
  const categories = [
    { id: 1, name: "personal" },
    { id: 2, name: "work" },
    { id: 3, name: "learning" },
  ];

  const priorities = [
    { id: 1, name: "urgent", color: "bg-danger" },
    { id: 2, name: "high", color: "bg-danger" },
    { id: 3, name: "normal", color: "bg-warning" },
    { id: 4, name: "low", color: "bg-success" },
    { id: 5, name: "very low", color: "bg-success" }
  ];

  const taskItems = [
    {
      id: 1,
      title: "Create UI for TaskMgt System",
      details: "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Hic numquam magni repellendus pariatur facilis cum praesentium repellat labore voluptate provident atque, asperiores aliquam maxime ex quaerat aperiam. Culpa, quam dolore!",
      duedate: new Date("2024-2-20"),
      progress: 60,
      priority: priorities[1],
      category: categories[0]
    },
    {
      id: 2,
      title: "aaaaaaaa aaaaaaaaaa aaaaa",
      details: "aaaaaaaaa aaaaaaaaaaaaa aaaaaaaaa aaaaaaaaaaa aaaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaaaa aaaaaaaaaaa aaaaaaaaaaa aaaaaaaaaa",
      duedate: new Date("2024-2-5"),
      progress: 75,
      priority: priorities[1],
      category: categories[0]
    },
  ]


  return (
    <>
      <Header />
      <Container fluid>

        <SearchTask />
      </Container>
      <Container fluid>
        <Row>
          <Col>
            <TaskItemList tasks={taskItems} heading="Top Products" icon="fas fa-arrow-circle-right" />
          </Col>
        </Row>
      </Container>
    </>
  );
}

export default App;
