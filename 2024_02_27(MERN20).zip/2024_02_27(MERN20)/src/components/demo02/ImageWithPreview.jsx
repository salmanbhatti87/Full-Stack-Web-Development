import { Fragment, useState } from "react";
import { Card, Col, Row } from "react-bootstrap";

function ImageWithPreview(props) {

    const [currentImage,changeCurrentImage]=useState(props.images[0]);


    function handleMouseEnter(e) {
        const temp = e.target.getAttribute("src");
        //it is not recmended option
        //const elt = document.getElementById("imgMain");
        //elt.setAttribute("src", temp);
        changeCurrentImage(prev=>temp);
    }

    function renderContents() {
        return (<Row>
            <Col className="col-9" >
                <img id="imgMain" src={currentImage} alt="" className="w-100" />
            </Col>
            <Col className="col-3 ps-0" >
                {
                    props.images.map(img => {
                        return (
                            <div key={img} className="mb-1" >
                                <img src={img} alt="" className="w-100 img-thumbnail" onMouseEnter={handleMouseEnter} />
                            </div>
                        )
                    })
                }
            </Col>
        </Row>);
    }

    function renderWithBorders(){
        return(
            <Card className="border" >
                <Card.Body>
                    {renderContents()} 
                </Card.Body>
            </Card>
        )
    }

    function renderWithOutBorders(){
        return(
            renderContents()
        )
    }

    return (
        <>
            {
                (props.borderless==='true') ? renderWithOutBorders() : renderWithBorders()
            }
        </>
    )

    // return (
    //     <>        
    //         {/* <Fragment> */}
    //         {/* <div>One</div> */}
    //         {/* <div>Two</div> */}
    //         {/* </Fragment> */}
    //     </>
    // )
}

export default ImageWithPreview;