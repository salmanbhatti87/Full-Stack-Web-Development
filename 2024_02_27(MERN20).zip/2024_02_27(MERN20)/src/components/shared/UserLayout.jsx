export default function(props){
    return(
        <>
            <header>Header</header>
            <main> Contents </main>
            <footer>Footer</footer>
        </>
    )
}
