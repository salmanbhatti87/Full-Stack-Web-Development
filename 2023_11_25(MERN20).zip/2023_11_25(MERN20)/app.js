const express=require("express");
const app=express();

const {handler}=require("./mymodules/locations")
const data=handler();

const port=3000;
const host="localhost";

app.get("/home",(req,res)=>{

   let temp=`<html><head><title>Home page</title></head><body>`;
   temp +=`<h1>Home Page</h1>`;
   temp +=`<ul>`;
   data.GetCities().forEach(c=>{
      temp+=`<li>${c.Name}</li>`
   });
   temp+=`</ul>`
   temp +=`</body></html>`;
   return res.status(200).send(temp);
});


app.get("/about",(req,res)=>{
   return res.status(200).send("<html><head><title>about page</title></head><body><h1>About Page</h1></body></html>");
});






app.listen(port,host,()=>{
   console.log(`Server is listening on port#${port}`);
})

