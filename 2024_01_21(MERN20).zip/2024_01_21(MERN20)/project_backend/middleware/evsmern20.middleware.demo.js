
const timeLog=function(req,res,next){
    console.log(`Recieved on ${new Date()}`);
    next();
}

const userLog=function(req,res,next){
    console.log(req.ip);
    next();
}



module.exports={ timeLog, userLog };
