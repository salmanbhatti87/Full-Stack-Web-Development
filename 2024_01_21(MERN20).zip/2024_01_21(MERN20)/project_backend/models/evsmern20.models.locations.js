const {mogoose,Schema, Model, SchemaType, SchemaTypes, model }=require("mongoose");

const countrySchema=new Schema({
    "name" : {
       "type" : SchemaTypes.String,
       "required" : true,
    },
    "code" : {
        "type" : SchemaTypes.Number,
        "min" : 1,
        "max" : 300        
    }
});

const Country=model("Country",countrySchema);

const provinceSchema=new Schema({
    "name" : {
        "type" : SchemaTypes.String,
       "required" : true,
    },
    "country" : {
        "type": SchemaTypes.ObjectId,
        "ref" : "Country",
        "required" : true
    }
});

const Province=model("Province",provinceSchema);

const citySchema=new Schema({
    "name" : SchemaTypes.String,
    "province" : {
        "type" : SchemaTypes.ObjectId,
        "ref" : "Province",
        "required" : true
    }
});

const City=model("City",citySchema);

const cityAreaSchema=new Schema({
    "name" : {
        "type": SchemaTypes.String,
        "required" : true,
    },
    "city": {
        "type" : SchemaTypes.ObjectId,
        "ref" : "City",
        "required" : true
    }
})


const CityArea=model("CityArea",cityAreaSchema);

module.exports={ Country,Province,City,CityArea };