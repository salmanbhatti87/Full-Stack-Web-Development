const express = require("express");
const provincesRouter = express.Router();
const { locations } = require("../dal/evsmern20.dal.locations");

provincesRouter.get("/", (req, res) => {
    locations.GetProvinces()
        .then(result => {
            console.log(result);
            return res.status(200).json(result);
        })
        .catch(error => {
            console.log(error);
            return res.status(500).send("server side error");
        })
})

provincesRouter.get("/:id", (req, res) => {
    locations.GetProvince(req.params.id)
        .then(result => {
            console.log(result);
            return res.status(200).json(result);
        })
        .catch(error => {
            console.log(error);
            return res.status(500).send("server side error");
        })
})

provincesRouter.post("/", async (req, res) => {
    try {
        const inserted = await locations.AddProvince(req.body)
        return res.status(201).send(inserted);
    }
    catch(error){
        console.log(error);
        return res.status(500).send(`failed to add ${req.body}`);
    }
})


provincesRouter.put("/:id", async (req, res) => {
    try {
        const updated = await locations.UpdateProvince(req.params.id,req.body); 
        return res.status(200).send(updated);
    }
    catch(error){
        console.log(error);
        return res.status(500).send(`failed to update ${req.body}`);
    }
})

provincesRouter.delete("/:id", async (req, res) => {
    try {
        const deleted = await locations.DeleteProvince(req.params.id); 
        return res.status(200).send(deleted);
    }
    catch(error){
        console.log(error);
        return res.status(500).send(`failed to update ${req.body}`);
    }
})

module.exports = provincesRouter;