const express = require("express");
const countriesRouter = express.Router();
const { locations } = require("../dal/evsmern20.dal.locations");

countriesRouter.get("/", (req, res) => {
    locations.GetCountries()
        .then(result => {
            console.log(result);
            return res.status(200).json(result);
        })
        .catch(error => {
            console.log(error);
            return res.status(500).send("server side error");
        })
})

countriesRouter.get("/:id", (req, res) => {
    locations.GetCountry(req.params.id)
        .then(result => {
            console.log(result);
            return res.status(200).json(result);
        })
        .catch(error => {
            console.log(error);
            return res.status(500).send("server side error");
        })
})

countriesRouter.post("/", async (req, res) => {
    try {
        const inserted = await locations.AddCountry(req.body)
        return res.status(201).send(inserted);
    }
    catch(error){
        console.log(error);
        return res.status(500).send(`failed to add ${req.body}`);
    }
})


countriesRouter.put("/:id", async (req, res) => {
    try {
        const updated = await locations.UpdateCountry(req.params.id,req.body); 
        return res.status(200).send(updated);
    }
    catch(error){
        console.log(error);
        return res.status(500).send(`failed to update ${req.body}`);
    }
})

countriesRouter.delete("/:id", async (req, res) => {
    try {
        const deleted = await locations.DeleteCountry(req.params.id); 
        return res.status(200).send(deleted);
    }
    catch(error){
        console.log(error);
        return res.status(500).send(`failed to update ${req.body}`);
    }
})




module.exports = countriesRouter;