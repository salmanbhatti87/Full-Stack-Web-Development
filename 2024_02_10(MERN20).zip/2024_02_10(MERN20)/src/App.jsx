import './App.css';
import UserStatus from './components/demos/userstatus';
import { Col, Container, Row } from 'react-bootstrap';
import ImageWithPreview from './components/demo02/ImageWithPreview';
import ChildrenDemo from './components/demo03/ChildrenDemo';
import StateDemo from './components/demo04/StateDemo';

function App() {
  const images = [ "images/garments/p1.jpg","images/garments/p2.jpg","images/garments/p3.jpg"  ];
  return (
    <Container fluid >
      <Row>
        <Col><UserStatus userName="alimalik" role="admin" /></Col>
      </Row>
      <Row>
        <Col>
            <StateDemo />
        </Col>
        <Col>
          <ImageWithPreview images={images} borderless="true"  />
        </Col>
        <Col>
          <ChildrenDemo>
            <p>One</p>
            <p>Two</p>
            <p>Three</p>
          </ChildrenDemo>
        </Col>
      </Row>
    </Container>

  );
}

export default App;
