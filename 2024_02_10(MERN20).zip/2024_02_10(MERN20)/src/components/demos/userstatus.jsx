import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import "./userstatus.css"

export default function UserStatus(props) {
    const temp=props.userName;
    return(
        <>
            <div className="userstatus-sec my-3">
                <FontAwesomeIcon icon="fas fa-user" /> <strong>{ (temp!=null) ? `${props.userName}, ${props.role}` : "guest" }</strong>
            </div>
        </>
    )
}