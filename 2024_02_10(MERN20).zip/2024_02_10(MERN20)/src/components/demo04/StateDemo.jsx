import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Button } from "react-bootstrap";
import "./statedemo.css";
import { useState } from "react";

export default function StateDemo() {

    const [counter, updateCounter] = useState(5);

    function handleIncrementClick(e) {
        updateCounter(prev => {
            let temp = prev + 1;
            return (temp > 100) ? 100 : temp;
        });
    }

    function handleDecrementClick(e) {
        updateCounter(prev => {
            let temp = prev - 1;
            return (temp < 0) ? 0 : temp;
        });
    }


    return (
        <>
            <Button variant="primary" onClick={handleDecrementClick} ><FontAwesomeIcon icon="fas fa-minus" />  </Button>
            <span className="counter-label">{counter}</span>
            <Button variant="primary" onClick={handleIncrementClick} ><FontAwesomeIcon icon="fas fa-plus" />  </Button>
        </>
    )
}
