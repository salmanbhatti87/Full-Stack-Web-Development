function ChildrenDemo(props) {
    let index=-1;
    return (
        <>
            <div>{
                props.children.map(x => <div key={++index} className="bg-primary text-white p-3 m-3">{x}</div>)
            }</div>
        </>
    )
}

export default ChildrenDemo;