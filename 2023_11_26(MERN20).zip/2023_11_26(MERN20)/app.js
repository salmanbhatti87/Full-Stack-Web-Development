const express = require("express");
const app = express();
const port = 8000;
const host = "localhost";

const { handler } = require("./mymodules/locations");
const data=handler();

//basic routing example
// app.get("/", (req, res) => {
//    try {
//       //throw new console.error();
//       res.setHeader("X-Author", "Mern20 Inc.");
//       res.setHeader("X-Copyright", "2023-2030");
//       return res.status(200).send("welcome to express server");
//    }
//    catch {
//       return res.status(500).send("server error");
//    }
// });





app.get("/cities", (req, res) => {
   try {
      const list =data.GetCities();
      return res.status(200).json(list);
   }
   catch {
      return res.status(500).send("server error");
   }
});



app.get("/cities/:name", (req, res) => {
   try {
      const cityName =req.params.name;
      const city =data.GetCity(cityName);
      if(city){
         return res.status(200).json(city);
      }
      return res.status(404).send(`city with name:${cityName} is not found`);    
  }
  catch {
     return res.status(500).send("server error");
  }
});


app.all("*",(req,res)=>{
   return res.status(404).send("not found");
});







app.listen(port, host, () => {
   console.log(`Server is listening on port#${port}`);
})

