//  const http=require("http");
//  const { Country, City, handler  } =require("./mymodules/locations");

// const server = http.createServer(function(req,res){
//     const obj=handler();


//     const cities=obj.GetCities();
//     const jsonData=JSON.stringify(cities);
//     res.end(jsonData);
//     res.end("test");
// });

// server.listen("7878","localhost",()=>{
//     console.log("server is ready");
// });

 const express=require("express");
 const { Country, City, handler  } =require("./mymodules/locations");
 const app=express();
 const data=handler();

 app.get("/",(req,res)=>{
    const list = data.GetCities();
    res.status(200).json(list);
 })




 app.listen(8888,"localhost",() =>{
    console.log("server is ready");
 });














