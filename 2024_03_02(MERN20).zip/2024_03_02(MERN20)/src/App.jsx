import './App.css';
import { Route, Routes } from 'react-router-dom';
import MainLayout from './components/MainLayout';
import Home from './components/Home';
import TasksList from './components/TasksList';
import AdminLayout from './components/AdminLayout';
import AdminHome from './components/AdminHome';
import ManageTeam from './components/ManageTeam';
import ManageTasks from './components/ManageTasks';

function App() {
  return (
    <>
      <Routes>
            <Route path='/' element={<MainLayout />}>
                <Route index element={<Home />} />
                <Route path='/home' element={<Home />} />
                <Route path='/tasks/:statusId' element={<TasksList/>} />                
            </Route>
            <Route path='/admin/' element={<AdminLayout />}>
                <Route index element={<AdminHome />} />
                <Route path='home' element={<AdminHome />} />
                <Route path='teams' element={<ManageTeam />} />                
                <Route path='tasks' element={<ManageTasks />} />                
            </Route>
      </Routes>
    </>
  );
}

export default App;
