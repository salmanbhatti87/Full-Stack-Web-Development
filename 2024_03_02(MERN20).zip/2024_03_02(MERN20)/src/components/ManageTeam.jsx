export default function ManageTeam(){
    return(
        <>
            <div>Manage Teams</div>
        </>
    )
}