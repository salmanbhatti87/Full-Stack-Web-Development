import { Col, Row } from "react-bootstrap";
import { Outlet } from "react-router-dom";

export default function AdminLayout(){
    return(
        <>
            <div>Admin</div>
            <Row>
                <Col className="col-3">Left</Col>
                <Col className="col-3">
                    <Outlet />
                </Col>
            </Row>
            <div>footer</div>
        </>
    )
}