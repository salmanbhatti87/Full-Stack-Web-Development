import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Navbar, Container, Nav } from "react-bootstrap";
import { Link, Outlet } from "react-router-dom";


export default function MainLayout() {
    return (
        <>
            <Navbar expand="lg" className="bg-primary navbar-dark">
                <Container fluid>
                    <Navbar.Brand href="#home">React-Bootstrap</Navbar.Brand>
                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav">
                        <Nav className="me-auto">
                            <Link to="/tasks/1" className="nav-link active"><FontAwesomeIcon icon="fas fa-clipboard" /> Pending</Link>
                            <Link to="/tasks/2" className="nav-link" ><FontAwesomeIcon icon="fas fa-clipboard-list" /> InProgress</Link>
                            <Link to="/tasks/3" className="nav-link" ><FontAwesomeIcon icon="fas fa-clipboard-check" /> Completed</Link>
                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar>
            <Container fluid>
                <Outlet />
            </Container>
            <Container fluid>footer </Container>
        </>
    )
}