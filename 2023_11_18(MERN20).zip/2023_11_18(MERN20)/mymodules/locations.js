class Country{
    constructor(id,name,code){
        this.Id=id;
        this.Name=name;
        this.Code=code;
    }

    get Summary(){
        return `${this.Id},${this.Code},${this.Name}`;
    }
}

class City{
    constructor(id,name,country){
        this.Id=id;
        this.Name=name;
        this.Country=country;
    }

    get Summary(){
        return `${this.Id},${this.Name},${this.Country.Name}`;
    }
}

class LocationsHandler{
    constructor(){
        this.counteries=[
            new Country(1,"Pakistan",92),
            new Country(2,"Afghanistan",93)
        ];

        this.cities=[
            new City(1,"Lahore",this.counteries[0]),
            new City(2,"Islamabad",this.counteries[0]),
            new City(3,"Karachi",this.counteries[0]),
            new City(4,"Kabul",this.counteries[1])
        ];
    }

    GetCity(id){
        return this.cities.find(c=>c.Id==id);
    }

    GetCities(){
        return [...this.cities];
    }
}




module.exports={Country,City,LocationsHandler};