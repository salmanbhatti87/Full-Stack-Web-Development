const { Console, error } = require("console");
const os = require("os");
const prompt = require("prompt");
const { GetMessage,SetMessage }=require("./mymodules/first");
const {Country,City,LocationsHandler  } =require("./mymodules/locations");

const handler=new LocationsHandler();

// const city = handler.GetCity(1);
// console.log(city);

const cities = handler.GetCities();
cities.forEach(c=>console.log(c));



//const Message=require("./mymodules/location");
//const x=require("./mymodules/location");
//x.SetMessage("ali at evs");
//console.log(x.GetMessage());
//let data=[10,20,30];
//let [x,y,z]=data;
//console.log(z);
//let obj={ "Id": 1, "Name" : "Aaa", "Price" : 1000 };
//let {Price:z}=obj;
//console.log(z);

// let names=["ali","ahmed","kashif","majid"];
// let [first,second,...data]=names;
//M1(10,20,100,1000)
// function M1(p1,p2,...data){
//     console.log(p1);
//     console.log(p2);
//     data.forEach(d => {
//         console.log(d);
//     });
// }











