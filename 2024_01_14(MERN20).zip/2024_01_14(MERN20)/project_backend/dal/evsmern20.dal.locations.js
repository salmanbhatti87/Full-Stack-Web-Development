const { mongoose } = require("mongoose");
const { Country, Province, City, CityArea } = require("../models/evsmern20.models.locations");
const dotenv=require("dotenv");
dotenv.config();

class LocationsHandler {

    async GetCountries() {
        try {
            mongoose.connect(process.env.CON_STR);
            return await Country.find();
        }
        catch (error) {
            console.log(error);
        }
    }

    async GetCountry(id) {
        try {
            mongoose.connect(process.env.CON_STR);
            return await Country.findById(id);
        }
        catch (error) {
            console.log(error);
        }
    }


    async AddCountry(country) {
        try {
            mongoose.connect(process.env.CON_STR);
            const insertedCountry =await Country.create(country)
            return insertedCountry;
        }
        catch (error) {
            console.log(error);
        }
    }

    async UpdateCountry(id,country){
        try {
            mongoose.connect(process.env.CON_STR);
            const result =await Country.updateOne({ "_id":id},country);
            if(result.modifiedCount>0){
                return country;
            }
            else {
                return null;
            }
        }
        catch(error){
            console.log(error);
        }        
    }

    async DeleteCountry(id){
        try {
            mongoose.connect(process.env.CON_STR);
            const result =await Country.deleteOne({ "_id":id});
            console.log(result);
        }
        catch(error){
            console.log(error);
        }        
    }


}

const locations = new LocationsHandler()

module.exports = { locations }

