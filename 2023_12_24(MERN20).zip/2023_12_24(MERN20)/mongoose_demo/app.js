const initDB = require("./common/evsmern20.common.intidb");
const { locations } = require("./dal/evsmern20.dal.locations")




// locations.GetCountry("6586e8e353c8aea553b4b6ae")
// .then(country=>console.log(country));

// locations.AddCountry({"name": "USA", "code" : 1 })
// .then(country=>{
//     if(country){
//         console.log(`${country.name} inserted successfully`);
//     }
//     else {
//         console.log(`failed to insert country:${country.name}`);
//     }   
// });

// locations.UpdateCountry(
//     { "_id": "6586e8e353c8aea553b4b6ae", "name": "UK", "code": 44 }
// ).then(result => {
//     if(result){
//         console.log(result);
//         console.log(`${result.name} is updated`);
//     }
//     else {
//         console.log(`failed to update`);
//     }    
//     // locations.GetCountries()
//     //     .then(countries => {
//     //         countries.forEach(c => console.log(c));
//     //     });

// })


locations.DeleteCountry("6586e8e353c8aea553b4b6ae").then(result=>{
    console.log(`deleted`);
})










