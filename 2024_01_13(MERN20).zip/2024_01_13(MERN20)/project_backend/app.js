const express=require("express");
const path=require("path");
const dotenv=require("dotenv");
const countriesRouter=require("./routes/evsmern20.routes.countries");


dotenv.config();
const app = express();
const port=process.env.PORT;
const host =process.env.HOST;
const publicFolder=path.resolve(__dirname,process.env.PUBLIC_FOLDER);
app.use(express.static(publicFolder));


// app.get("/",function(req,res){
//     return res.send("test");
// })

app.use("/api/countries",countriesRouter);
app.use(express.urlencoded({extended:false}));
app.use(express.json());

app.all("*",(req,res)=>{
    return res.status(404).send("not found");
})

app.listen(port,host,function(){
    console.log(`server is listening on ${port}`);
})

