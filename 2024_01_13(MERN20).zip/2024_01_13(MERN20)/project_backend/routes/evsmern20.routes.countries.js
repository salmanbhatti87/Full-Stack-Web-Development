const express =require("express");
const countriesRouter=express.Router();
const { locations } =require("../dal/evsmern20.dal.locations");

countriesRouter.get("/",(req,res)=>{
    locations.GetCountries()
    .then(result=>{
        console.log(result);
        return res.status(200).json(result);
    })
    .catch(error=>{
        console.log(error);
        return res.status(500).send("server side error");
    })
})

countriesRouter.get("/:id",(req,res)=>{
    locations.GetCountry(req.params.id)
    .then(result=>{
        console.log(result);
        return res.status(200).json(result);
    })
    .catch(error=>{
        console.log(error);
        return res.status(500).send("server side error");
    })
})

countriesRouter.post("/",(req,res)=>{
     console.log(req.body);
    // locations.GetCountry(req.params.id)
    // .then(result=>{
    //     console.log(result);
    //     return res.status(200).json(result);
    // })
    // .catch(error=>{
    //     console.log(error);
    //     return res.status(500).send("server side error");
    // })
})




module.exports=countriesRouter;